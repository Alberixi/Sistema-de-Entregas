<?php
// Configuração do banco de dados
define('DB_HOST', 'localhost');
define('DB_NAME', 'sistema_entregas');
define('DB_USER', 'root');
define('DB_PASS', '');

// Configurações do sistema
define('SITE_URL', 'http://localhost/sistema-entregas');
define('SITE_NAME', 'Sistema de Entregas');

// Configurações de sessão

// Função para conectar ao banco de dados
function conectarDB()
{
    try {
        $conn = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8", DB_USER, DB_PASS);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch (PDOException $e) {
        die("Erro de conexão: " . $e->getMessage());
    }
}

// Função para gerar código de entrega único
function gerarCodigoEntrega()
{
    return 'ENT-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));
}

// Função para formatar data
function formatarData($data)
{
    return date('d/m/Y', strtotime($data));
}

// Função para formatar valor monetário
function formatarValor($valor)
{
    return 'R$ ' . number_format($valor, 2, ',', '.');
}

// Função para limpar dados
function limparDados($dados)
{
    $dados = trim($dados);
    $dados = stripslashes($dados);
    $dados = htmlspecialchars($dados);
    return $dados;
}

// Função para verificar se usuário está logado (para futura implementação de login)
function estaLogado()
{
    return isset($_SESSION['usuario_id']);
}

// Função para redirecionar
function redirecionar($url)
{
    header("Location: $url");
    exit();
}

// Função para mostrar mensagem de alerta
function mostrarAlerta($mensagem, $tipo = 'info')
{
    $_SESSION['alerta'] = [
        'mensagem' => $mensagem,
        'tipo' => $tipo
    ];
}

// Função para exibir alerta
function exibirAlerta()
{
    if (isset($_SESSION['alerta'])) {
        $alerta = $_SESSION['alerta'];
        unset($_SESSION['alerta']);

        $classe = '';
        switch ($alerta['tipo']) {
            case 'sucesso':
                $classe = 'alert-success';
                break;
            case 'erro':
                $classe = 'alert-danger';
                break;
            case 'aviso':
                $classe = 'alert-warning';
                break;
            default:
                $classe = 'alert-info';
        }

        echo '<div class="alert ' . $classe . ' alert-dismissible fade show" role="alert">';
        echo $alerta['mensagem'];
        echo '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
        echo '</div>';
    }
}
