<?php
require_once 'config/database.php';
require_once 'includes/header.php';
require_once 'includes/sidebar.php';

$conn = conectarDB();
$periodo = isset($_GET['periodo']) ? $_GET['periodo'] : '6meses';

// Calcular data de início baseada no período
$dataInicio = new DateTime();
switch ($periodo) {
    case '1mes':
        $dataInicio->sub(new DateInterval('P1M'));
        break;
    case '3meses':
        $dataInicio->sub(new DateInterval('P3M'));
        break;
    case '6meses':
        $dataInicio->sub(new DateInterval('P6M'));
        break;
    case '1ano':
        $dataInicio->sub(new DateInterval('P1Y'));
        break;
    case 'todos':
        $dataInicio->setDate(2000, 1, 1);
        break;
}

$dataInicioStr = $dataInicio->format('Y-m-d H:i:s');

try {
    // Buscar entregas por status
    $stmt = $conn->prepare("SELECT status, COUNT(*) as total FROM entregas WHERE created_at >= ? GROUP BY status");
    $stmt->execute([$dataInicioStr]);
    $entregasPorStatus = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Buscar entregas por mês
    $stmt = $conn->prepare("
        SELECT DATE_FORMAT(created_at, '%Y-%m') as mes, COUNT(*) as total 
        FROM entregas 
        WHERE created_at >= ? 
        GROUP BY DATE_FORMAT(created_at, '%Y-%m')
        ORDER BY mes
    ");
    $stmt->execute([$dataInicioStr]);
    $entregasPorMes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Buscar clientes mais ativos
    $stmt = $conn->prepare("
        SELECT c.nome, COUNT(e.id) as total_entregas, MAX(e.created_at) as ultima_entrega
        FROM clientes c
        LEFT JOIN entregas e ON c.id = e.cliente_id AND e.created_at >= ?
        GROUP BY c.id, c.nome
        HAVING total_entregas > 0
        ORDER BY total_entregas DESC
        LIMIT 10
    ");
    $stmt->execute([$dataInicioStr]);
    $clientesMaisAtivos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Calcular estatísticas gerais
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM entregas WHERE created_at >= ?");
    $stmt->execute([$dataInicioStr]);
    $totalEntregas = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM entregas WHERE status = 'ENTREGUE' AND created_at >= ?");
    $stmt->execute([$dataInicioStr]);
    $entregasConcluidas = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

    $taxaSucesso = $totalEntregas > 0 ? round(($entregasConcluidas / $totalEntregas) * 100) : 0;
} catch (PDOException $e) {
    echo "Erro: " . $e->getMessage();
}

// Processar exportação
if (isset($_GET['exportar'])) {
    $formato = $_GET['exportar'];

    try {
        // Buscar todos os dados para exportação
        $stmt = $conn->prepare("
            SELECT e.*, c.nome as cliente_nome, c.email as cliente_email, c.telefone as cliente_telefone
            FROM entregas e
            LEFT JOIN clientes c ON e.cliente_id = c.id
            WHERE e.created_at >= ?
            ORDER BY e.created_at DESC
        ");
        $stmt->execute([$dataInicioStr]);
        $entregas = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($formato == 'csv') {
            header('Content-Type: text/csv');
            header('Content-Disposition: attachment; filename="relatorio_entregas_' . date('Y-m-d') . '.csv"');

            $output = fopen('php://output', 'w');
            fputcsv($output, ['Código', 'Descrição', 'Status', 'Cliente', 'Email', 'Telefone', 'Endereço', 'Cidade', 'Estado', 'CEP', 'Data Criação', 'Data Entrega']);

            foreach ($entregas as $entrega) {
                fputcsv($output, [
                    $entrega['codigo'],
                    $entrega['descricao'],
                    $entrega['status'],
                    $entrega['cliente_nome'],
                    $entrega['cliente_email'],
                    $entrega['cliente_telefone'],
                    $entrega['endereco'],
                    $entrega['cidade'],
                    $entrega['estado'],
                    $entrega['cep'],
                    $entrega['created_at'],
                    $entrega['data_entrega']
                ]);
            }

            fclose($output);
            exit();
        } elseif ($formato == 'excel') {
            header('Content-Type: application/vnd.ms-excel');
            header('Content-Disposition: attachment; filename="relatorio_entregas_' . date('Y-m-d') . '.xls"');

            echo '<table border="1">';
            echo '<tr><th>Código</th><th>Descrição</th><th>Status</th><th>Cliente</th><th>Email</th><th>Telefone</th><th>Endereço</th><th>Cidade</th><th>Estado</th><th>CEP</th><th>Data Criação</th><th>Data Entrega</th></tr>';

            foreach ($entregas as $entrega) {
                echo '<tr>';
                echo '<td>' . $entrega['codigo'] . '</td>';
                echo '<td>' . $entrega['descricao'] . '</td>';
                echo '<td>' . $entrega['status'] . '</td>';
                echo '<td>' . $entrega['cliente_nome'] . '</td>';
                echo '<td>' . $entrega['cliente_email'] . '</td>';
                echo '<td>' . $entrega['cliente_telefone'] . '</td>';
                echo '<td>' . $entrega['endereco'] . '</td>';
                echo '<td>' . $entrega['cidade'] . '</td>';
                echo '<td>' . $entrega['estado'] . '</td>';
                echo '<td>' . $entrega['cep'] . '</td>';
                echo '<td>' . $entrega['created_at'] . '</td>';
                echo '<td>' . $entrega['data_entrega'] . '</td>';
                echo '</tr>';
            }

            echo '</table>';
            exit();
        }
    } catch (PDOException $e) {
        echo "Erro ao exportar: " . $e->getMessage();
    }
}
?>

<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Relatórios</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item active">Relatórios</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <section class="content">
        <div class="container-fluid">
            <!-- Filtros e Exportação -->
            <div class="row mb-3">
                <div class="col-md-6">
                    <form method="GET" class="row g-3">
                        <div class="col-md-6">
                            <select name="periodo" class="form-select" onchange="this.form.submit()">
                                <option value="1mes" <?php echo $periodo == '1mes' ? 'selected' : ''; ?>>Último mês</option>
                                <option value="3meses" <?php echo $periodo == '3meses' ? 'selected' : ''; ?>>Últimos 3 meses</option>
                                <option value="6meses" <?php echo $periodo == '6meses' ? 'selected' : ''; ?>>Últimos 6 meses</option>
                                <option value="1ano" <?php echo $periodo == '1ano' ? 'selected' : ''; ?>>Último ano</option>
                                <option value="todos" <?php echo $periodo == 'todos' ? 'selected' : ''; ?>>Todo período</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <button type="submit" class="btn btn-secondary">
                                <i class="fas fa-filter"></i> Filtrar
                            </button>
                        </div>
                    </form>
                </div>
                <div class="col-md-6 text-end">
                    <div class="btn-group">
                        <a href="?periodo=<?php echo $periodo; ?>&exportar=csv" class="btn btn-success">
                            <i class="fas fa-file-csv"></i> Exportar CSV
                        </a>
                        <a href="?periodo=<?php echo $periodo; ?>&exportar=excel" class="btn btn-primary">
                            <i class="fas fa-file-excel"></i> Exportar Excel
                        </a>
                    </div>
                </div>
            </div>

            <!-- Cards de Resumo -->
            <div class="row mb-4">
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3><?php echo $totalEntregas; ?></h3>
                            <p>Total Entregas</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-box"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-success">
                        <div class="inner">
                            <h3><?php echo $taxaSucesso; ?>%</h3>
                            <p>Taxa de Sucesso</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-chart-line"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-warning">
                        <div class="inner">
                            <h3><?php echo count($clientesMaisAtivos); ?></h3>
                            <p>Clientes Ativos</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-users"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-danger">
                        <div class="inner">
                            <h3><?php echo count($entregasPorMes); ?></h3>
                            <p>Meses Ativos</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-calendar"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Gráficos e Tabelas -->
            <div class="row">
                <!-- Status das Entregas -->
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">Status das Entregas</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Status</th>
                                            <th>Quantidade</th>
                                            <th>Percentual</th>
                                            <th>Visualização</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($entregasPorStatus as $status): ?>
                                            <?php
                                            $percentual = $totalEntregas > 0 ? round(($status['total'] / $totalEntregas) * 100) : 0;
                                            $cor = '';
                                            switch ($status['status']) {
                                                case 'PENDENTE':
                                                    $cor = '#ffc107';
                                                    break;
                                                case 'EM_TRANSITO':
                                                    $cor = '#17a2b8';
                                                    break;
                                                case 'ENTREGUE':
                                                    $cor = '#28a745';
                                                    break;
                                                case 'CANCELADO':
                                                    $cor = '#dc3545';
                                                    break;
                                            }
                                            ?>
                                            <tr>
                                                <td>
                                                    <span class="badge" style="background-color: <?php echo $cor; ?>">
                                                        <?php echo $status['status']; ?>
                                                    </span>
                                                </td>
                                                <td><?php echo $status['total']; ?></td>
                                                <td><?php echo $percentual; ?>%</td>
                                                <td>
                                                    <div class="progress" style="height: 20px;">
                                                        <div class="progress-bar" role="progressbar" style="width: <?php echo $percentual; ?>%; background-color: <?php echo $cor; ?>">
                                                            <?php echo $percentual; ?>%
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Entregas por Mês -->
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">Entregas por Mês</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Mês</th>
                                            <th>Quantidade</th>
                                            <th>Tendência</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($entregasPorMes as $index => $mes): ?>
                                            <?php
                                            $meses = [
                                                '01' => 'Jan',
                                                '02' => 'Fev',
                                                '03' => 'Mar',
                                                '04' => 'Abr',
                                                '05' => 'Mai',
                                                '06' => 'Jun',
                                                '07' => 'Jul',
                                                '08' => 'Ago',
                                                '09' => 'Set',
                                                '10' => 'Out',
                                                '11' => 'Nov',
                                                '12' => 'Dez'
                                            ];

                                            $dataMes = DateTime::createFromFormat('Y-m', $mes['mes']);
                                            $mesFormatado = $meses[$dataMes->format('m')] . '/' . $dataMes->format('Y');

                                            $anterior = $entregasPorMes[$index - 1] ?? null;
                                            $tendencia = '';
                                            if ($anterior) {
                                                $diferenca = $mes['total'] - $anterior['total'];
                                                if ($diferenca > 0) {
                                                    $tendencia = '<span class="text-success"><i class="fas fa-arrow-up"></i> +' . $diferenca . '</span>';
                                                } elseif ($diferenca < 0) {
                                                    $tendencia = '<span class="text-danger"><i class="fas fa-arrow-down"></i> ' . $diferenca . '</span>';
                                                } else {
                                                    $tendencia = '<span class="text-secondary"><i class="fas fa-minus"></i> 0</span>';
                                                }
                                            }
                                            ?>
                                            <tr>
                                                <td><?php echo $mesFormatado; ?></td>
                                                <td><?php echo $mes['total']; ?></td>
                                                <td><?php echo $tendencia; ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Clientes Mais Ativos -->
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">Clientes Mais Ativos</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>Cliente</th>
                                            <th>Total de Entregas</th>
                                            <th>Última Entrega</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($clientesMaisAtivos as $cliente): ?>
                                            <tr>
                                                <td><strong><?php echo $cliente['nome']; ?></strong></td>
                                                <td><?php echo $cliente['total_entregas']; ?></td>
                                                <td><?php echo $cliente['ultima_entrega'] ? formatarData($cliente['ultima_entrega']) : 'Nunca'; ?></td>
                                                <td>
                                                    <?php if ($cliente['total_entregas'] >= 10): ?>
                                                        <span class="badge bg-success">Muito Ativo</span>
                                                    <?php elseif ($cliente['total_entregas'] >= 5): ?>
                                                        <span class="badge bg-info">Ativo</span>
                                                    <?php else: ?>
                                                        <span class="badge bg-secondary">Regular</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php require_once 'includes/footer.php'; ?>