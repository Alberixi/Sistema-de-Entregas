<?php
// Script para gerar arquivo ZIP do sistema
// Salve este arquivo como criar_zip.php e acesse via navegador

function criarZipSistema() {
    $diretorio = __DIR__;
    $nomeZip = 'sistema-entregas.zip';
    $zip = new ZipArchive();
    
    if ($zip->open($nomeZip, ZipArchive::CREATE | ZipArchive::OVERWRITE) === TRUE) {
        // Adicionar todos os arquivos PHP
        $arquivos = [
            'index.php',
            'install.php', 
            'dashboard.php',
            'relatorios.php',
            'database.sql',
            'README.md'
        ];
        
        foreach ($arquivos as $arquivo) {
            if (file_exists($diretorio . '/' . $arquivo)) {
                $zip->addFile($diretorio . '/' . $arquivo, $arquivo);
            }
        }
        
        // Adicionar diretórios inteiros
        $diretorios = ['config', 'clientes', 'entregas', 'includes', 'assets'];
        
        foreach ($diretorios as $dir) {
            if (is_dir($diretorio . '/' . $dir)) {
                $arquivosDir = new RecursiveIteratorIterator(
                    new RecursiveDirectoryIterator($diretorio . '/' . $dir),
                    RecursiveIteratorIterator::SELF_FIRST
                );
                
                foreach ($arquivosDir as $arquivo) {
                    if (!$arquivo->isDir()) {
                        $caminhoRelativo = substr($arquivo->getPathname(), strlen($diretorio) + 1);
                        $zip->addFile($arquivo->getPathname(), $caminhoRelativo);
                    }
                }
            }
        }
        
        $zip->close();
        
        // Forçar download
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . $nomeZip . '"');
        header('Content-Length: ' . filesize($nomeZip));
        header('Pragma: no-cache');
        header('Expires: 0');
        readfile($nomeZip);
        
        // Remover arquivo temporário
        unlink($nomeZip);
        exit;
    } else {
        echo "Não foi possível criar o arquivo ZIP";
    }
}

// Executar a função
criarZipSistema();
?>