<?php
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/sidebar.php';

$conn = conectarDB();
$erro = '';
$sucesso = '';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    redirecionar('listar.php');
}

$id = $_GET['id'];

// Buscar dados do cliente
try {
    $stmt = $conn->prepare("SELECT * FROM clientes WHERE id = ?");
    $stmt->execute([$id]);
    $cliente = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$cliente) {
        redirecionar('listar.php');
    }
} catch (PDOException $e) {
    die("Erro: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = limparDados($_POST['nome']);
    $email = limparDados($_POST['email']);
    $telefone = limparDados($_POST['telefone']);
    $endereco = limparDados($_POST['endereco']);
    $cidade = limparDados($_POST['cidade']);
    $estado = limparDados($_POST['estado']);
    $cep = limparDados($_POST['cep']);

    try {
        // Verificar se email já existe (exceto para o mesmo cliente)
        if (!empty($email)) {
            $stmt = $conn->prepare("SELECT id FROM clientes WHERE email = ? AND id != ?");
            $stmt->execute([$email, $id]);
            if ($stmt->fetch()) {
                $erro = 'Este email já está cadastrado para outro cliente!';
            }
        }

        if (empty($erro)) {
            $sql = "UPDATE clientes SET nome = ?, email = ?, telefone = ?, endereco = ?, cidade = ?, estado = ?, cep = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->execute([$nome, $email, $telefone, $endereco, $cidade, $estado, $cep, $id]);

            mostrarAlerta('Cliente atualizado com sucesso!', 'sucesso');
            redirecionar('listar.php');
        }
    } catch (PDOException $e) {
        $erro = 'Erro ao atualizar cliente: ' . $e->getMessage();
    }
}
?>
<!-- Remove duplicate PHP block and start HTML correctly -->
<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Editar Cliente</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                        <li class="breadcrumb-item"><a href="../clientes/listar.php">Clientes</a></li>
                        <li class="breadcrumb-item active">Editar</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">Editar Cliente: <?php echo htmlspecialchars($cliente['nome']); ?></h5>
                        </div>
                        <div class="card-body">
                            <?php if ($erro): ?>
                                <div class="alert alert-danger">
                                    <i class="fas fa-exclamation-triangle me-2"></i>
                                    <?php echo $erro; ?>
                                </div>
                            <?php endif; ?>

                            <form method="POST">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="nome" class="form-label">Nome *</label>
                                            <input type="text" class="form-control" id="nome" name="nome" value="<?php echo htmlspecialchars($cliente['nome']); ?>" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="email" class="form-label">Email</label>
                                            <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($cliente['email']); ?>">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="telefone" class="form-label">Telefone</label>
                                            <input type="text" class="form-control" id="telefone" name="telefone" value="<?php echo htmlspecialchars($cliente['telefone']); ?>" placeholder="(00) 00000-0000">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="cep" class="form-label">CEP</label>
                                            <input type="text" class="form-control" id="cep" name="cep" value="<?php echo htmlspecialchars($cliente['cep']); ?>" placeholder="00000-000">
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label for="endereco" class="form-label">Endereço</label>
                                    <input type="text" class="form-control" id="endereco" name="endereco" value="<?php echo htmlspecialchars($cliente['endereco']); ?>">
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="cidade" class="form-label">Cidade</label>
                                            <input type="text" class="form-control" id="cidade" name="cidade" value="<?php echo htmlspecialchars($cliente['cidade']); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="mb-3">
                                            <label for="estado" class="form-label">Estado</label>
                                            <select class="form-select" id="estado" name="estado">
                                                <option value="">Selecione...</option>
                                                <option value="AC" <?php echo $cliente['estado'] == 'AC' ? 'selected' : ''; ?>>AC</option>
                                                <option value="AL" <?php echo $cliente['estado'] == 'AL' ? 'selected' : ''; ?>>AL</option>
                                                <option value="AP" <?php echo $cliente['estado'] == 'AP' ? 'selected' : ''; ?>>AP</option>
                                                <option value="AM" <?php echo $cliente['estado'] == 'AM' ? 'selected' : ''; ?>>AM</option>
                                                <option value="BA" <?php echo $cliente['estado'] == 'BA' ? 'selected' : ''; ?>>BA</option>
                                                <option value="CE" <?php echo $cliente['estado'] == 'CE' ? 'selected' : ''; ?>>CE</option>
                                                <option value="DF" <?php echo $cliente['estado'] == 'DF' ? 'selected' : ''; ?>>DF</option>
                                                <option value="ES" <?php echo $cliente['estado'] == 'ES' ? 'selected' : ''; ?>>ES</option>
                                                <option value="GO" <?php echo $cliente['estado'] == 'GO' ? 'selected' : ''; ?>>GO</option>
                                                <option value="MA" <?php echo $cliente['estado'] == 'MA' ? 'selected' : ''; ?>>MA</option>
                                                <option value="MT" <?php echo $cliente['estado'] == 'MT' ? 'selected' : ''; ?>>MT</option>
                                                <option value="MS" <?php echo $cliente['estado'] == 'MS' ? 'selected' : ''; ?>>MS</option>
                                                <option value="MG" <?php echo $cliente['estado'] == 'MG' ? 'selected' : ''; ?>>MG</option>
                                                <option value="PA" <?php echo $cliente['estado'] == 'PA' ? 'selected' : ''; ?>>PA</option>
                                                <option value="PB" <?php echo $cliente['estado'] == 'PB' ? 'selected' : ''; ?>>PB</option>
                                                <option value="PR" <?php echo $cliente['estado'] == 'PR' ? 'selected' : ''; ?>>PR</option>
                                                <option value="PE" <?php echo $cliente['estado'] == 'PE' ? 'selected' : ''; ?>>PE</option>
                                                <option value="PI" <?php echo $cliente['estado'] == 'PI' ? 'selected' : ''; ?>>PI</option>
                                                <option value="RJ" <?php echo $cliente['estado'] == 'RJ' ? 'selected' : ''; ?>>RJ</option>
                                                <option value="RN" <?php echo $cliente['estado'] == 'RN' ? 'selected' : ''; ?>>RN</option>
                                                <option value="RS" <?php echo $cliente['estado'] == 'RS' ? 'selected' : ''; ?>>RS</option>
                                                <option value="RO" <?php echo $cliente['estado'] == 'RO' ? 'selected' : ''; ?>>RO</option>
                                                <option value="RR" <?php echo $cliente['estado'] == 'RR' ? 'selected' : ''; ?>>RR</option>
                                                <option value="SC" <?php echo $cliente['estado'] == 'SC' ? 'selected' : ''; ?>>SC</option>
                                                <option value="SP" <?php echo $cliente['estado'] == 'SP' ? 'selected' : ''; ?>>SP</option>
                                                <option value="SE" <?php echo $cliente['estado'] == 'SE' ? 'selected' : ''; ?>>SE</option>
                                                <option value="TO" <?php echo $cliente['estado'] == 'TO' ? 'selected' : ''; ?>>TO</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="d-flex justify-content-between">
                                    <a href="listar.php" class="btn btn-secondary">
                                        <i class="fas fa-arrow-left me-2"></i>Voltar
                                    </a>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save me-2"></i>Atualizar Cliente
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php require_once '../includes/footer.php'; ?>