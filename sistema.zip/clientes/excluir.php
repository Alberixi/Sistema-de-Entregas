<?php
require_once '../config/database.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    redirecionar('listar.php');
}

$id = $_GET['id'];

try {
    $conn = conectarDB();
    
    // Verificar se cliente tem entregas associadas
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM entregas WHERE cliente_id = ?");
    $stmt->execute([$id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result['total'] > 0) {
        mostrarAlerta('Não é possível excluir este cliente pois existem entregas associadas a ele.', 'erro');
        redirecionar('listar.php');
    }
    
    // Excluir cliente
    $stmt = $conn->prepare("DELETE FROM clientes WHERE id = ?");
    $stmt->execute([$id]);
    
    mostrarAlerta('Cliente excluído com sucesso!', 'sucesso');
    redirecionar('listar.php');
    
} catch(PDOException $e) {
    mostrarAlerta('Erro ao excluir cliente: ' . $e->getMessage(), 'erro');
    redirecionar('listar.php');
}
?>