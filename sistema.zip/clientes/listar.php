<?php
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/sidebar.php';

$conn = conectarDB();
$busca = '';
$clientes = [];

// Processar busca
if (isset($_GET['busca'])) {
    $busca = limparDados($_GET['busca']);
}

try {
    $sql = "SELECT * FROM clientes WHERE 1=1";
    $params = [];

    if (!empty($busca)) {
        $sql .= " AND (nome LIKE ? OR email LIKE ? OR telefone LIKE ? OR cidade LIKE ?)";
        $buscaParam = "%$busca%";
        $params = [$buscaParam, $buscaParam, $buscaParam, $buscaParam];
    }

    $sql .= " ORDER BY nome";

    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    $clientes = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Erro: " . $e->getMessage();
}
?>

<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Clientes</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                        <li class="breadcrumb-item active">Clientes</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="row align-items-center">
                                <div class="col-md-6">
                                    <h5 class="card-title mb-0">Lista de Clientes</h5>
                                </div>
                                <div class="col-md-6 text-end">
                                    <a href="adicionar.php" class="btn btn-primary">
                                        <i class="fas fa-plus me-2"></i>Novo Cliente
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <!-- Formulário de busca -->
                            <form method="GET" class="mb-3">
                                <div class="row">
                                    <div class="col-md-10">
                                        <input type="text" name="busca" class="form-control" placeholder="Buscar por nome, email, telefone ou cidade..." value="<?php echo htmlspecialchars($busca); ?>">
                                    </div>
                                    <div class="col-md-2">
                                        <button type="submit" class="btn btn-secondary w-100">
                                            <i class="fas fa-search"></i> Buscar
                                        </button>
                                    </div>
                                </div>
                            </form>

                            <!-- Tabela de clientes -->
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover">
                                    <thead class="table-dark">
                                        <tr>
                                            <th>ID</th>
                                            <th>Nome</th>
                                            <th>Email</th>
                                            <th>Telefone</th>
                                            <th>Cidade/UF</th>
                                            <th>Cadastro</th>
                                            <th>Ações</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (empty($clientes)): ?>
                                            <tr>
                                                <td colspan="7" class="text-center">Nenhum cliente encontrado</td>
                                            </tr>
                                        <?php else: ?>
                                            <?php foreach ($clientes as $cliente): ?>
                                                <tr>
                                                    <td><?php echo $cliente['id']; ?></td>
                                                    <td><strong><?php echo $cliente['nome']; ?></strong></td>
                                                    <td><?php echo $cliente['email'] ?: '-'; ?></td>
                                                    <td><?php echo $cliente['telefone'] ?: '-'; ?></td>
                                                    <td>
                                                        <?php
                                                        if ($cliente['cidade'] && $cliente['estado']) {
                                                            echo $cliente['cidade'] . '/' . $cliente['estado'];
                                                        } else {
                                                            echo '-';
                                                        }
                                                        ?>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        echo !empty($cliente['created_at']) ? formatarData($cliente['created_at']) : '-';
                                                        ?>
                                                    </td>
                                                    <td>
                                                        <div class="btn-group" role="group">
                                                            <a href="editar.php?id=<?php echo $cliente['id']; ?>" class="btn btn-sm btn-primary" title="Editar">
                                                                <i class="fas fa-edit"></i>
                                                            </a>
                                                            <a href="excluir.php?id=<?php echo $cliente['id']; ?>" class="btn btn-sm btn-danger" title="Excluir" onclick="return confirm('Tem certeza que deseja excluir este cliente?')">
                                                                <i class="fas fa-trash"></i>
                                                            </a>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>

                            <!-- Contador de resultados -->
                            <div class="mt-3">
                                <small class="text-muted">
                                    <?php echo count($clientes); ?> cliente(s) encontrado(s)
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php require_once '../includes/footer.php'; ?>