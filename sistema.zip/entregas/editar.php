<?php
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/sidebar.php';

$conn = conectarDB();
$erro = '';
$sucesso = '';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    redirecionar('listar.php');
}

$id = $_GET['id'];

// Buscar dados da entrega
try {
    $stmt = $conn->prepare("SELECT e.*, c.nome as cliente_nome FROM entregas e LEFT JOIN clientes c ON e.cliente_id = c.id WHERE e.id = ?");
    $stmt->execute([$id]);
    $entrega = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$entrega) {
        redirecionar('listar.php');
    }
    
    // Buscar clientes para o select
    $stmt = $conn->query("SELECT id, nome FROM clientes ORDER BY nome");
    $clientes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch(PDOException $e) {
    die("Erro: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $descricao = limparDados($_POST['descricao']);
    $clienteId = $_POST['cliente_id'];
    $endereco = limparDados($_POST['endereco']);
    $cidade = limparDados($_POST['cidade']);
    $estado = limparDados($_POST['estado']);
    $cep = limparDados($_POST['cep']);
    $dataEntrega = !empty($_POST['data_entrega']) ? $_POST['data_entrega'] : null;
    $status = $_POST['status'];

    try {
        $sql = "UPDATE entregas SET descricao = ?, cliente_id = ?, endereco = ?, cidade = ?, estado = ?, cep = ?, data_entrega = ?, status = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$descricao, $clienteId, $endereco, $cidade, $estado, $cep, $dataEntrega, $status, $id]);
        
        mostrarAlerta('Entrega atualizada com sucesso!', 'sucesso');
        redirecionar('listar.php');
    } catch(PDOException $e) {
        $erro = 'Erro ao atualizar entrega: ' . $e->getMessage();
    }
}
?>

<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Editar Entrega</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                        <li class="breadcrumb-item"><a href="listar.php">Entregas</a></li>
                        <li class="breadcrumb-item active">Editar</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-10 offset-md-1">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">Editar Entrega: <?php echo htmlspecialchars($entrega['codigo']); ?></h5>
                        </div>
                        <div class="card-body">
                            <?php if ($erro): ?>
                                <div class="alert alert-danger">
                                    <i class="fas fa-exclamation-triangle me-2"></i>
                                    <?php echo $erro; ?>
                                </div>
                            <?php endif; ?>

                            <form method="POST">
                                <div class="row">
                                    <div class="col-md-8">
                                        <div class="mb-3">
                                            <label for="descricao" class="form-label">Descrição *</label>
                                            <textarea class="form-control" id="descricao" name="descricao" rows="3" required><?php echo htmlspecialchars($entrega['descricao']); ?></textarea>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label for="cliente_id" class="form-label">Cliente *</label>
                                            <select class="form-select" id="cliente_id" name="cliente_id" required>
                                                <option value="">Selecione um cliente...</option>
                                                <?php foreach ($clientes as $cliente): ?>
                                                    <option value="<?php echo $cliente['id']; ?>" <?php echo $entrega['cliente_id'] == $cliente['id'] ? 'selected' : ''; ?>>
                                                        <?php echo htmlspecialchars($cliente['nome']); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label for="endereco" class="form-label">Endereço de Entrega *</label>
                                    <input type="text" class="form-control" id="endereco" name="endereco" value="<?php echo htmlspecialchars($entrega['endereco']); ?>" required>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="cidade" class="form-label">Cidade *</label>
                                            <input type="text" class="form-control" id="cidade" name="cidade" value="<?php echo htmlspecialchars($entrega['cidade']); ?>" required>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="mb-3">
                                            <label for="estado" class="form-label">Estado *</label>
                                            <select class="form-select" id="estado" name="estado" required>
                                                <option value="">Selecione...</option>
                                                <option value="AC" <?php echo $entrega['estado'] == 'AC' ? 'selected' : ''; ?>>AC</option>
                                                <option value="AL" <?php echo $entrega['estado'] == 'AL' ? 'selected' : ''; ?>>AL</option>
                                                <option value="AP" <?php echo $entrega['estado'] == 'AP' ? 'selected' : ''; ?>>AP</option>
                                                <option value="AM" <?php echo $entrega['estado'] == 'AM' ? 'selected' : ''; ?>>AM</option>
                                                <option value="BA" <?php echo $entrega['estado'] == 'BA' ? 'selected' : ''; ?>>BA</option>
                                                <option value="CE" <?php echo $entrega['estado'] == 'CE' ? 'selected' : ''; ?>>CE</option>
                                                <option value="DF" <?php echo $entrega['estado'] == 'DF' ? 'selected' : ''; ?>>DF</option>
                                                <option value="ES" <?php echo $entrega['estado'] == 'ES' ? 'selected' : ''; ?>>ES</option>
                                                <option value="GO" <?php echo $entrega['estado'] == 'GO' ? 'selected' : ''; ?>>GO</option>
                                                <option value="MA" <?php echo $entrega['estado'] == 'MA' ? 'selected' : ''; ?>>MA</option>
                                                <option value="MT" <?php echo $entrega['estado'] == 'MT' ? 'selected' : ''; ?>>MT</option>
                                                <option value="MS" <?php echo $entrega['estado'] == 'MS' ? 'selected' : ''; ?>>MS</option>
                                                <option value="MG" <?php echo $entrega['estado'] == 'MG' ? 'selected' : ''; ?>>MG</option>
                                                <option value="PA" <?php echo $entrega['estado'] == 'PA' ? 'selected' : ''; ?>>PA</option>
                                                <option value="PB" <?php echo $entrega['estado'] == 'PB' ? 'selected' : ''; ?>>PB</option>
                                                <option value="PR" <?php echo $entrega['estado'] == 'PR' ? 'selected' : ''; ?>>PR</option>
                                                <option value="PE" <?php echo $entrega['estado'] == 'PE' ? 'selected' : ''; ?>>PE</option>
                                                <option value="PI" <?php echo $entrega['estado'] == 'PI' ? 'selected' : ''; ?>>PI</option>
                                                <option value="RJ" <?php echo $entrega['estado'] == 'RJ' ? 'selected' : ''; ?>>RJ</option>
                                                <option value="RN" <?php echo $entrega['estado'] == 'RN' ? 'selected' : ''; ?>>RN</option>
                                                <option value="RS" <?php echo $entrega['estado'] == 'RS' ? 'selected' : ''; ?>>RS</option>
                                                <option value="RO" <?php echo $entrega['estado'] == 'RO' ? 'selected' : ''; ?>>RO</option>
                                                <option value="RR" <?php echo $entrega['estado'] == 'RR' ? 'selected' : ''; ?>>RR</option>
                                                <option value="SC" <?php echo $entrega['estado'] == 'SC' ? 'selected' : ''; ?>>SC</option>
                                                <option value="SP" <?php echo $entrega['estado'] == 'SP' ? 'selected' : ''; ?>>SP</option>
                                                <option value="SE" <?php echo $entrega['estado'] == 'SE' ? 'selected' : ''; ?>>SE</option>
                                                <option value="TO" <?php echo $entrega['estado'] == 'TO' ? 'selected' : ''; ?>>TO</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="mb-3">
                                            <label for="cep" class="form-label">CEP</label>
                                            <input type="text" class="form-control" id="cep" name="cep" value="<?php echo htmlspecialchars($entrega['cep']); ?>" placeholder="00000-000">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="data_entrega" class="form-label">Data Prevista de Entrega</label>
                                            <input type="date" class="form-control" id="data_entrega" name="data_entrega" value="<?php echo $entrega['data_entrega']; ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="status" class="form-label">Status</label>
                                            <select class="form-select" id="status" name="status">
                                                <option value="PENDENTE" <?php echo $entrega['status'] == 'PENDENTE' ? 'selected' : ''; ?>>Pendente</option>
                                                <option value="EM_TRANSITO" <?php echo $entrega['status'] == 'EM_TRANSITO' ? 'selected' : ''; ?>>Em Trânsito</option>
                                                <option value="ENTREGUE" <?php echo $entrega['status'] == 'ENTREGUE' ? 'selected' : ''; ?>>Entregue</option>
                                                <option value="CANCELADO" <?php echo $entrega['status'] == 'CANCELADO' ? 'selected' : ''; ?>>Cancelado</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="d-flex justify-content-between">
                                    <a href="listar.php" class="btn btn-secondary">
                                        <i class="fas fa-arrow-left me-2"></i>Voltar
                                    </a>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save me-2"></i>Atualizar Entrega
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php require_once '../includes/footer.php'; ?>