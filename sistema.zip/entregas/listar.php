<?php
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/sidebar.php';

$conn = conectarDB();
$busca = '';
$statusFilter = '';
$entregas = [];

// Processar filtros
if (isset($_GET['busca'])) {
    $busca = limparDados($_GET['busca']);
}
if (isset($_GET['status'])) {
    $statusFilter = limparDados($_GET['status']);
}

try {
    $sql = "SELECT e.*, c.nome as cliente_nome FROM entregas e LEFT JOIN clientes c ON e.cliente_id = c.id WHERE 1=1";
    $params = [];
    
    if (!empty($busca)) {
        $sql .= " AND (e.codigo LIKE ? OR e.descricao LIKE ? OR c.nome LIKE ? OR e.endereco LIKE ? OR e.cidade LIKE ?)";
        $buscaParam = "%$busca%";
        $params = array_merge($params, [$buscaParam, $buscaParam, $buscaParam, $buscaParam, $buscaParam]);
    }
    
    if (!empty($statusFilter)) {
        $sql .= " AND e.status = ?";
        $params[] = $statusFilter;
    }
    
    $sql .= " ORDER BY e.created_at DESC";
    
    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    $entregas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch(PDOException $e) {
    echo "Erro: " . $e->getMessage();
}
?>

<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Entregas</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                        <li class="breadcrumb-item active">Entregas</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="row align-items-center">
                                <div class="col-md-6">
                                    <h5 class="card-title mb-0">Lista de Entregas</h5>
                                </div>
                                <div class="col-md-6 text-end">
                                    <a href="adicionar.php" class="btn btn-primary">
                                        <i class="fas fa-plus me-2"></i>Nova Entrega
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <!-- Formulário de filtros -->
                            <form method="GET" class="mb-3">
                                <div class="row">
                                    <div class="col-md-5">
                                        <input type="text" name="busca" class="form-control" placeholder="Buscar por código, descrição, cliente ou endereço..." value="<?php echo htmlspecialchars($busca); ?>">
                                    </div>
                                    <div class="col-md-3">
                                        <select name="status" class="form-select">
                                            <option value="">Todos os status</option>
                                            <option value="PENDENTE" <?php echo $statusFilter == 'PENDENTE' ? 'selected' : ''; ?>>Pendente</option>
                                            <option value="EM_TRANSITO" <?php echo $statusFilter == 'EM_TRANSITO' ? 'selected' : ''; ?>>Em Trânsito</option>
                                            <option value="ENTREGUE" <?php echo $statusFilter == 'ENTREGUE' ? 'selected' : ''; ?>>Entregue</option>
                                            <option value="CANCELADO" <?php echo $statusFilter == 'CANCELADO' ? 'selected' : ''; ?>>Cancelado</option>
                                        </select>
                                    </div>
                                    <div class="col-md-2">
                                        <button type="submit" class="btn btn-secondary w-100">
                                            <i class="fas fa-filter"></i> Filtrar
                                        </button>
                                    </div>
                                    <div class="col-md-2">
                                        <a href="listar.php" class="btn btn-outline-secondary w-100">
                                            <i class="fas fa-times"></i> Limpar
                                        </a>
                                    </div>
                                </div>
                            </form>

                            <!-- Tabela de entregas -->
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover">
                                    <thead class="table-dark">
                                        <tr>
                                            <th>Código</th>
                                            <th>Descrição</th>
                                            <th>Cliente</th>
                                            <th>Endereço</th>
                                            <th>Status</th>
                                            <th>Data Entrega</th>
                                            <th>Cadastro</th>
                                            <th>Ações</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (empty($entregas)): ?>
                                            <tr>
                                                <td colspan="8" class="text-center">Nenhuma entrega encontrada</td>
                                            </tr>
                                        <?php else: ?>
                                            <?php foreach ($entregas as $entrega): ?>
                                                <tr>
                                                    <td><strong><?php echo $entrega['codigo']; ?></strong></td>
                                                    <td><?php echo $entrega['descricao']; ?></td>
                                                    <td>
                                                        <div>
                                                            <strong><?php echo $entrega['cliente_nome']; ?></strong>
                                                            <?php if ($entrega['cliente_nome']): ?>
                                                                <br>
                                                                <small class="text-muted">ID: <?php echo $entrega['cliente_id']; ?></small>
                                                            <?php endif; ?>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div>
                                                            <?php echo $entrega['endereco']; ?>
                                                            <br>
                                                            <small class="text-muted">
                                                                <?php echo $entrega['cidade']; ?>/<?php echo $entrega['estado']; ?>
                                                                <?php if ($entrega['cep']): ?>
                                                                    - CEP: <?php echo $entrega['cep']; ?>
                                                                <?php endif; ?>
                                                            </small>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        $statusClass = '';
                                                        $statusIcon = '';
                                                        switch($entrega['status']) {
                                                            case 'PENDENTE':
                                                                $statusClass = 'bg-warning';
                                                                $statusIcon = 'fas fa-clock';
                                                                break;
                                                            case 'EM_TRANSITO':
                                                                $statusClass = 'bg-info';
                                                                $statusIcon = 'fas fa-truck';
                                                                break;
                                                            case 'ENTREGUE':
                                                                $statusClass = 'bg-success';
                                                                $statusIcon = 'fas fa-check';
                                                                break;
                                                            case 'CANCELADO':
                                                                $statusClass = 'bg-danger';
                                                                $statusIcon = 'fas fa-times';
                                                                break;
                                                        }
                                                        ?>
                                                        <span class="badge <?php echo $statusClass; ?>">
                                                            <i class="<?php echo $statusIcon; ?> me-1"></i>
                                                            <?php echo $entrega['status']; ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <?php echo $entrega['data_entrega'] ? formatarData($entrega['data_entrega']) : '-'; ?>
                                                    </td>
                                                    <td><?php echo formatarData($entrega['created_at']); ?></td>
                                                    <td>
                                                        <div class="btn-group" role="group">
                                                            <a href="editar.php?id=<?php echo $entrega['id']; ?>" class="btn btn-sm btn-primary" title="Editar">
                                                                <i class="fas fa-edit"></i>
                                                            </a>
                                                            <a href="excluir.php?id=<?php echo $entrega['id']; ?>" class="btn btn-sm btn-danger" title="Excluir" onclick="return confirm('Tem certeza que deseja excluir esta entrega?')">
                                                                <i class="fas fa-trash"></i>
                                                            </a>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <!-- Contador de resultados -->
                            <div class="mt-3">
                                <small class="text-muted">
                                    <?php echo count($entregas); ?> entrega(s) encontrada(s)
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php require_once '../includes/footer.php'; ?>