<?php
require_once '../config/database.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    redirecionar('listar.php');
}

$id = $_GET['id'];

try {
    $conn = conectarDB();
    
    // Excluir entrega
    $stmt = $conn->prepare("DELETE FROM entregas WHERE id = ?");
    $stmt->execute([$id]);
    
    mostrarAlerta('Entrega excluída com sucesso!', 'sucesso');
    redirecionar('listar.php');
    
} catch(PDOException $e) {
    mostrarAlerta('Erro ao excluir entrega: ' . $e->getMessage(), 'erro');
    redirecionar('listar.php');
}
?>