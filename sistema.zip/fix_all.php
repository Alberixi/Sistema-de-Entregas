<?php
session_start();
ob_start();

// Nome do arquivo
$filename = 'fix_all.php';

// Verifica se está sendo acessado diretamente
if (!in_array(basename($_SERVER['SCRIPT_NAME']), [$filename, 'install.php'])) {
    die("Este arquivo deve ser executado diretamente.");
}

// Função para mostrar status
function status($msg, $tipo = 'info')
{
    $class = [
        'sucesso' => 'alert-success',
        'erro' => 'alert-danger',
        'aviso' => 'alert-warning',
        'info' => 'alert-info'
    ][$tipo] ?? 'alert-info';
    echo "<div class='alert $class mb-2'>$msg</div>";
}

// ================== 1. Verificar/Recriar config/database.php ==================
status("🔍 Verificando configuração do banco de dados...", 'info');

if (!file_exists('config/database.php')) {
    status("⚙️ Arquivo config/database.php não encontrado. Recriando...", 'aviso');

    if (!is_dir('config')) mkdir('config', 0755, true);

    $configContent = "<?php
// Configuração do banco de dados
define('DB_HOST', 'localhost');
define('DB_NAME', 'sistema_entregas');
define('DB_USER', 'root');
define('DB_PASS', '');

// URL do sistema
define('SITE_URL', 'http://' . \$_SERVER['HTTP_HOST'] . rtrim(dirname(\$_SERVER['PHP_SELF']), '/\\\\') . '/');
define('SITE_NAME', 'Sistema de Entregas');
?>

<?php
session_start();

function conectarDB() {
    try {
        \$conn = new PDO(\"mysql:host=\".DB_HOST.\";dbname=\".DB_NAME.\";charset=utf8\", DB_USER, DB_PASS);
        \$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return \$conn;
    } catch(PDOException \$e) {
        die(\"Erro de conexão: \" . \$e->getMessage());
    }
}

function formatarData(\$data) {
    return \$data ? date('d/m/Y', strtotime(\$data)) : '';
}

function formatarValor(\$valor) {
    return 'R\$ ' . number_format(\$valor, 2, ',', '.');
}

function limparDados(\$dados) {
    \$dados = trim(\$dados);
    \$dados = stripslashes(\$dados);
    \$dados = htmlspecialchars(\$dados);
    return \$dados;
}

function mostrarAlerta(\$msg, \$tipo = 'info') {
    \$_SESSION['alerta'] = ['mensagem' => \$msg, 'tipo' => \$tipo];
}

function exibirAlerta() {
    if (isset(\$_SESSION['alerta'])) {
        \$a = \$_SESSION['alerta'];
        unset(\$_SESSION['alerta']);
        \$c = ['sucesso'=>'alert-success','erro'=>'alert-danger','aviso'=>'alert-warning','info'=>'alert-info'][\$a['tipo']] ?? 'alert-info';
        echo \"<div class='alert \$c alert-dismissible fade show' role='alert'>\";
        echo \$a['mensagem'];
        echo \"<button type='button' class='btn-close' data-bs-dismiss='alert'></button></div>\";
    }
}
?>";

    if (file_put_contents('config/database.php', $configContent)) {
        status("✅ config/database.php criado com sucesso!", 'sucesso');
    } else {
        status("❌ Falha ao criar config/database.php. Verifique permissões.", 'erro');
        ob_end_flush();
        exit;
    }
} else {
    status("✅ config/database.php já existe.", 'sucesso');
}

// ================== 2. Incluir config para usar conectarDB ==================
require_once 'config/database.php';

// ================== 3. Verificar/Recriar tabelas ==================
status("🔧 Verificando tabelas do banco de dados...", 'info');

try {
    $conn = conectarDB();

    // Verificar se tabela clientes existe
    $stmt = $conn->query("SHOW TABLES LIKE 'clientes'");
    if ($stmt->rowCount() == 0) {
        status("🔄 Tabela 'clientes' não encontrada. Recriando...", 'aviso');

        $sql = file_get_contents('database.sql');
        if (!$sql) {
            throw new Exception("Arquivo database.sql não encontrado.");
        }

        $statements = array_filter(array_map('trim', preg_split('/;$/m', $sql)));
        foreach ($statements as $stmt_sql) {
            if (!empty($stmt_sql)) {
                $conn->exec($stmt_sql);
            }
        }
        status("✅ Tabelas recriadas com sucesso!", 'sucesso');
    } else {
        status("✅ Tabela 'clientes' já existe.", 'sucesso');
    }
} catch (Exception $e) {
    status("❌ Erro ao verificar banco: " . $e->getMessage(), 'erro');
}

// ================== 4. Verificar pastas essenciais ==================
$dirs = ['clientes', 'entregas', 'includes', 'assets/css', 'assets/js', 'assets/img'];
foreach ($dirs as $dir) {
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
        status("📁 Criada pasta: $dir", 'aviso');
    }
}

// ================== 5. Verificar arquivos básicos ==================
if (!file_exists('assets/css/style.css')) {
    file_put_contents('assets/css/style.css', "/* Estilo será gerado depois */");
    status("🎨 Criado: assets/css/style.css", 'aviso');
}

if (!file_exists('assets/js/script.js')) {
    file_put_contents('assets/js/script.js', "// JavaScript será gerado depois");
    status("⚡ Criado: assets/js/script.js", 'aviso');
}

// ================== 6. Finalizar ==================
status("🎉 <strong>Sistema recuperado com sucesso!</strong>", 'sucesso');
status("➡️ <a href='index.php' class='btn btn-primary'>Acessar o Sistema</a>", 'info');

ob_end_flush();
// ...existing code...
$conn = conectarDB();
$campos = [
    'nome VARCHAR(100)',
    'email VARCHAR(100)',
    'telefone VARCHAR(20)',
    'endereco VARCHAR(255)',
    'cidade VARCHAR(100)',
    'estado VARCHAR(2)',
    'cep VARCHAR(10)'
];
foreach ($campos as $campo) {
    $nomeCampo = explode(' ', $campo)[0];
    $sql = "ALTER TABLE clientes ADD COLUMN IF NOT EXISTS $campo";
    try {
        $conn->query($sql);
    } catch (PDOException $e) { /* Ignorar se já existe */
    }
}
// ...existing code...