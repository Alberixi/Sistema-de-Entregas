<!-- Sidebar Menu -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index.php" class="brand-link">
        <img src="assets/img/logo.png" alt="Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
        <span class="brand-text font-weight-light">Sistema de Entregas</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <img src="assets/img/user.png" class="img-circle elevation-2" alt="User Image">
            </div>
            <div class="info">
                <a href="#" class="d-block">Administrador</a>
            </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <li class="nav-item">
                    <a href="index.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                
                <li class="nav-item">
                    <a href="clientes/listar.php" class="nav-link <?php echo strpos($_SERVER['PHP_SELF'], 'clientes') !== false ? 'active' : ''; ?>">
                        <i class="nav-icon fas fa-users"></i>
                        <p>Clientes</p>
                    </a>
                </li>
                
                <li class="nav-item">
                    <a href="entregas/listar.php" class="nav-link <?php echo strpos($_SERVER['PHP_SELF'], 'entregas') !== false ? 'active' : ''; ?>">
                        <i class="nav-icon fas fa-box"></i>
                        <p>Entregas</p>
                    </a>
                </li>
                
                <li class="nav-item">
                    <a href="relatorios.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'relatorios.php' ? 'active' : ''; ?>">
                        <i class="nav-icon fas fa-chart-bar"></i>
                        <p>Relatórios</p>
                    </a>
                </li>
                
                <li class="nav-header">Ferramentas</li>
                
                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-cog"></i>
                        <p>Configurações</p>
                    </a>
                </li>
                
                <li class="nav-item">
                    <a href="install.php" class="nav-link">
                        <i class="nav-icon fas fa-database"></i>
                        <p>Instalação</p>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</aside>