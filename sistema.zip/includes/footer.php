<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo defined('SITE_URL') ? SITE_URL : '/'; ?>assets/js/script.js"></script>

<!-- Botão de alternar tema (único) -->
<button id="theme-toggle" title="Alternar tema"></button>

<!-- Page specific scripts -->
<?php if (isset($pageScripts)): ?>
    <?php echo $pageScripts; ?>
<?php endif; ?>
<!-- Botão de alternar tema (único no sistema) -->
<button id="theme-toggle" class="btn btn-outline-warning" title="Alternar tema">
    <i class="fas fa-moon"></i>
</button>
</body>

</html>