<?php
session_start();
require_once '../config/database.php';
require_once '../includes/header.php';

// Função para mostrar mensagens
function alert($mensagem, $tipo = 'info')
{
    $class = [
        'sucesso' => 'alert-success',
        'erro' => 'alert-danger',
        'aviso' => 'alert-warning',
        'info' => 'alert-info'
    ][$tipo] ?? 'alert-info';

    echo "<div class='alert $class alert-dismissible fade show' role='alert'>
            $mensagem
            <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
          </div>";
}

$mensagem = '';

if (isset($_POST['recuperar'])) {
    try {
        $conn = conectarDB();

        // === 1. Recriar tabelas ===
        $sql = file_get_contents('../database.sql');
        if (!$sql) {
            throw new Exception("Arquivo database.sql não encontrado.");
        }

        $statements = array_filter(array_map('trim', preg_split('/;$/m', $sql)));
        foreach ($statements as $stmt) {
            if (!empty($stmt)) {
                $conn->exec($stmt);
            }
        }

        // === 2. Recriar config/database.php se não existir ===
        if (!file_exists('../config/database.php')) {
            $configContent = "<?php
// Configuração do banco de dados
define('DB_HOST', 'localhost');
define('DB_NAME', 'sistema_entregas');
define('DB_USER', 'root');
define('DB_PASS', '');

// URL do sistema
define('SITE_URL', 'http://' . \$_SERVER['HTTP_HOST'] . rtrim(dirname(\$_SERVER['PHP_SELF']), '/\\\\') . '/../');
define('SITE_NAME', 'Sistema de Entregas');
?>

<?php
session_start();

function conectarDB() {
    try {
        \$conn = new PDO(\"mysql:host=\".DB_HOST.\";dbname=\".DB_NAME.\";charset=utf8\", DB_USER, DB_PASS);
        \$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return \$conn;
    } catch(PDOException \$e) {
        die(\"Erro de conexão: \" . \$e->getMessage());
    }
}

function formatarData(\$data) {
    return \$data ? date('d/m/Y', strtotime(\$data)) : '';
}

function formatarValor(\$valor) {
    return 'R\$ ' . number_format(\$valor, 2, ',', '.');
}

function limparDados(\$dados) {
    \$dados = trim(\$dados);
    \$dados = stripslashes(\$dados);
    \$dados = htmlspecialchars(\$dados);
    return \$dados;
}

function mostrarAlerta(\$msg, \$tipo = 'info') {
    \$_SESSION['alerta'] = ['mensagem' => \$msg, 'tipo' => \$tipo];
}

function exibirAlerta() {
    if (isset(\$_SESSION['alerta'])) {
        \$a = \$_SESSION['alerta']; unset(\$_SESSION['alerta']);
        \$c = ['sucesso'=>'alert-success','erro'=>'alert-danger','aviso'=>'alert-warning']['\$a['tipo']'] ?? 'alert-info';
        echo \"<div class='alert \$c'>\$a['mensagem']</div>\";
    }
}
?>";

            if (!is_dir('../config')) mkdir('../config', 0755, true);
            file_put_contents('../config/database.php', $configContent);
        }

        // === 3. Recriar pastas essenciais ===
        $pastas = ['../config', '../includes', '../clientes', '../entregas'];
        foreach ($pastas as $pasta) {
            if (!is_dir($pasta)) {
                mkdir($pasta, 0755, true);
            }
        }

        // === 4. Arquivos básicos de includes ===
        if (!file_exists('../includes/header.php')) {
            file_put_contents('../includes/header.php', "<!DOCTYPE html>... <!-- seu header -->");
        }
        if (!file_exists('../includes/footer.php')) {
            file_put_contents('../includes/footer.php', "</body></html>");
        }

        $mensagem = "✅ Sistema recuperado com sucesso! Tabelas recriadas, arquivos essenciais restaurados.";
    } catch (Exception $e) {
        alert("❌ Erro ao recuperar: " . $e->getMessage(), 'erro');
    }
}
?>

<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Recuperação do Sistema</h1>
                </div>
            </div>
        </div>
    </div>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4>🔧 Ferramenta de Recuperação</h4>
                            <p>Este utilitário recria tabelas, arquivos de configuração e pastas essenciais do sistema.</p>

                            <?php if ($mensagem): ?>
                                <div class="alert alert-success"><?= $mensagem ?></div>
                            <?php endif; ?>

                            <form method="POST">
                                <button type="submit" name="recuperar" class="btn btn-danger btn-lg">
                                    <i class="fas fa-redo"></i> Recuperar Tudo
                                </button>
                            </form>

                            <hr>
                            <h5>📋 Verificações realizadas:</h5>
                            <ul>
                                <li>✅ Banco de dados conectado: <strong><?= defined('DB_NAME') ? 'Sim' : 'Não' ?></strong></li>
                                <li>📁 Arquivo config/database.php: <strong><?= file_exists('../config/database.php') ? 'OK' : 'Faltando' ?></strong></li>
                                <li>📁 database.sql: <strong><?= file_exists('../database.sql') ? 'OK' : 'Faltando' ?></strong></li>
                                <li>🛠️ Tabelas: clientes, entregas — serão recriadas se necessário</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php require_once '../includes/footer.php'; ?>