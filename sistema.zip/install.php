<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$error = '';
$success = '';

// Verifica se já foi instalado (opcional)
if (file_exists('config/database.php') && strpos(file_get_contents('config/database.php'), 'DB_NAME') !== false) {
    $success = 'Sistema já está instalado! <a href="index.php">Clique aqui para acessar</a>';
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && !$success) {
    $host = $_POST['host'] ?? 'localhost';
    $dbname = $_POST['dbname'] ?? 'sistema_entregas';
    $user = $_POST['user'] ?? 'root';
    $pass = $_POST['pass'] ?? '';

    try {
        // Testar conexão com o servidor MySQL
        $conn = new PDO("mysql:host=$host", $user, $pass);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Criar banco de dados se não existir
        $conn->exec("CREATE DATABASE IF NOT EXISTS `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $conn->exec("USE `$dbname`");

        // Ler o arquivo SQL
        if (!file_exists('database.sql')) {
            throw new Exception("Arquivo database.sql não encontrado. Verifique se está no diretório correto.");
        }

        $sql = file_get_contents('database.sql');
        if ($sql === false) {
            throw new Exception("Erro ao ler o arquivo database.sql.");
        }

        // Executar o SQL (pode conter múltiplos comandos)
        $statements = array_filter(array_map('trim', preg_split('/;$/m', $sql)));
        foreach ($statements as $stmt) {
            if (!empty($stmt)) {
                $conn->exec($stmt);
            }
        }

        // Garantir campo created_at na tabela clientes
        $conn->exec("ALTER TABLE clientes ADD COLUMN IF NOT EXISTS created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP");

        // Conteúdo do arquivo de configuração
        $configContent = "<?php\n";
        $configContent .= "// Configuração do banco de dados\n";
        $configContent .= "define('DB_HOST', '" . addslashes($host) . "');\n";
        $configContent .= "define('DB_NAME', '" . addslashes($dbname) . "');\n";
        $configContent .= "define('DB_USER', '" . addslashes($user) . "');\n";
        $configContent .= "define('DB_PASS', '" . addslashes($pass) . "');\n\n";

        $configContent .= "// Configurações do sistema\n";
        $configContent .= "define('SITE_URL', 'http://' . \$_SERVER['HTTP_HOST'] . rtrim(dirname(\$_SERVER['PHP_SELF']), '/\\\\') . '/');\n";
        $configContent .= "define('SITE_NAME', 'Sistema de Entregas');\n\n";

        $configContent .= "// Configurações de sessão\n";
        $configContent .= "session_start();\n\n";

        $configContent .= "// Função para conectar ao banco de dados\n";
        $configContent .= "function conectarDB() {\n";
        $configContent .= "    try {\n";
        $configContent .= "        \$conn = new PDO(\"mysql:host=\".DB_HOST.\";dbname=\".DB_NAME.\";charset=utf8\", DB_USER, DB_PASS);\n";
        $configContent .= "        \$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);\n";
        $configContent .= "        return \$conn;\n";
        $configContent .= "    } catch(PDOException \$e) {\n";
        $configContent .= "        die(\"Erro de conexão: \" . \$e->getMessage());\n";
        $configContent .= "    }\n";
        $configContent .= "}\n\n";

        $configContent .= "// Função para gerar código de entrega único\n";
        $configContent .= "function gerarCodigoEntrega() {\n";
        $configContent .= "    return 'ENT-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));\n";
        $configContent .= "}\n\n";

        $configContent .= "// Função para formatar data\n";
        $configContent .= "function formatarData(\$data) {\n";
        $configContent .= "    return date('d/m/Y', strtotime(\$data));\n";
        $configContent .= "}\n\n";

        $configContent .= "// Função para formatar valor monetário\n";
        $configContent .= "function formatarValor(\$valor) {\n";
        $configContent .= "    return 'R\$ ' . number_format(\$valor, 2, ',', '.');\n";
        $configContent .= "}\n\n";

        $configContent .= "// Função para limpar dados\n";
        $configContent .= "function limparDados(\$dados) {\n";
        $configContent .= "    \$dados = trim(\$dados);\n";
        $configContent .= "    \$dados = stripslashes(\$dados);\n";
        $configContent .= "    \$dados = htmlspecialchars(\$dados);\n";
        $configContent .= "    return \$dados;\n";
        $configContent .= "}\n\n";

        $configContent .= "// Função para verificar se usuário está logado\n";
        $configContent .= "function estaLogado() {\n";
        $configContent .= "    return isset(\$_SESSION['usuario_id']);\n";
        $configContent .= "}\n\n";

        $configContent .= "// Função para redirecionar\n";
        $configContent .= "function redirecionar(\$url) {\n";
        $configContent .= "    header(\"Location: \$url\");\n";
        $configContent .= "    exit();\n";
        $configContent .= "}\n\n";

        $configContent .= "// Função para mostrar mensagem de alerta\n";
        $configContent .= "function mostrarAlerta(\$mensagem, \$tipo = 'info') {\n";
        $configContent .= "    \$_SESSION['alerta'] = [\n";
        $configContent .= "        'mensagem' => \$mensagem,\n";
        $configContent .= "        'tipo' => \$tipo\n";
        $configContent .= "    ];\n";
        $configContent .= "}\n\n";

        $configContent .= "// Função para exibir alerta\n";
        $configContent .= "function exibirAlerta() {\n";
        $configContent .= "    if (isset(\$_SESSION['alerta'])) {\n";
        $configContent .= "        \$alerta = \$_SESSION['alerta'];\n";
        $configContent .= "        unset(\$_SESSION['alerta']);\n\n";

        $configContent .= "        \$classe = '';\n";
        $configContent .= "        switch(\$alerta['tipo']) {\n";
        $configContent .= "            case 'sucesso':\n";
        $configContent .= "                \$classe = 'alert-success';\n";
        $configContent .= "                break;\n";
        $configContent .= "            case 'erro':\n";
        $configContent .= "                \$classe = 'alert-danger';\n";
        $configContent .= "                break;\n";
        $configContent .= "            case 'aviso':\n";
        $configContent .= "                \$classe = 'alert-warning';\n";
        $configContent .= "                break;\n";
        $configContent .= "            default:\n";
        $configContent .= "                \$classe = 'alert-info';\n";
        $configContent .= "        }\n\n";

        $configContent .= "        echo '<div class=\"alert ' . \$classe . ' alert-dismissible fade show\" role=\"alert\">';\n";
        $configContent .= "        echo \$alerta['mensagem'];\n";
        $configContent .= "        echo '<button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"alert\"></button>';\n";
        $configContent .= "        echo '</div>';\n";
        $configContent .= "    }\n";
        $configContent .= "}\n";
        $configContent .= "?>";

        // Verificar se a pasta config/ existe
        if (!is_dir('config')) {
            if (!mkdir('config', 0755, true)) {
                throw new Exception("Não foi possível criar a pasta 'config/'. Verifique as permissões.");
            }
        }

        // Escrever o arquivo
        if (file_put_contents('config/database.php', $configContent) === false) {
            throw new Exception("Não foi possível salvar o arquivo config/database.php. Verifique as permissões da pasta.");
        }

        $success = 'Sistema instalado com sucesso! <a href="index.php">Clique aqui para acessar</a>';
    } catch (Exception $e) {
        $error = 'Erro na instalação: ' . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instalação - Sistema de Entregas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .install-container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
            padding: 40px;
            max-width: 600px;
            width: 100%;
        }

        .install-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .install-header h1 {
            color: #333;
            margin-bottom: 10px;
        }

        .install-header p {
            color: #666;
        }

        .form-control:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            border-radius: 25px;
            padding: 12px 30px;
        }

        .btn-primary:hover {
            background: linear-gradient(135deg, #5a6fd8 0%, #6a4190 100%);
        }

        .alert {
            border-radius: 10px;
            border: none;
        }
    </style>
</head>

<body>
    <div class="install-container">
        <div class="install-header">
            <i class="fas fa-truck fa-3x text-primary mb-3"></i>
            <h1>Sistema de Entregas</h1>
            <p>Instalação do Sistema</p>
        </div>

        <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle me-2"></i>
                <?php echo $success; ?>
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle me-2"></i>
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <?php if (!$success): ?>
            <form method="POST">
                <div class="mb-3">
                    <label for="host" class="form-label">Host do Banco de Dados</label>
                    <input type="text" class="form-control" id="host" name="host" value="localhost" required>
                </div>
                <div class="mb-3">
                    <label for="dbname" class="form-label">Nome do Banco de Dados</label>
                    <input type="text" class="form-control" id="dbname" name="dbname" value="sistema_entregas" required>
                </div>
                <div class="mb-3">
                    <label for="user" class="form-label">Usuário do Banco de Dados</label>
                    <input type="text" class="form-control" id="user" name="user" value="root" required>
                </div>
                <div class="mb-3">
                    <label for="pass" class="form-label">Senha do Banco de Dados</label>
                    <input type="password" class="form-control" id="pass" name="pass" placeholder="Deixe em branco se não houver senha">
                </div>
                <div class="d-grid">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-cog me-2"></i>
                        Instalar Sistema
                    </button>
                </div>
            </form>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>