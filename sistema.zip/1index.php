<?php
require_once 'config/database.php';
require_once 'includes/header.php';
require_once 'includes/sidebar.php';

// Conectar ao banco de dados
$conn = conectarDB();

// Buscar estatísticas do dashboard
try {
    // Total de clientes
    $stmt = $conn->query("SELECT COUNT(*) as total FROM clientes");
    $totalClientes = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    // Total de entregas
    $stmt = $conn->query("SELECT COUNT(*) as total FROM entregas");
    $totalEntregas = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    // Entregas por status
    $stmt = $conn->query("SELECT status, COUNT(*) as total FROM entregas GROUP BY status");
    $entregasPorStatus = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Entregas recentes
    $stmt = $conn->query("
        SELECT e.*, c.nome as cliente_nome 
        FROM entregas e 
        LEFT JOIN clientes c ON e.cliente_id = c.id 
        ORDER BY e.created_at DESC 
        LIMIT 10
    ");
    $entregasRecentes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch(PDOException $e) {
    echo "Erro: " . $e->getMessage();
}

// Organizar dados por status
$statusCounts = [
    'PENDENTE' => 0,
    'EM_TRANSITO' => 0,
    'ENTREGUE' => 0,
    'CANCELADO' => 0
];

foreach ($entregasPorStatus as $status) {
    $statusCounts[$status['status']] = $status['total'];
}

// Calcular taxa de entrega
$taxaEntrega = $totalEntregas > 0 ? round(($statusCounts['ENTREGUE'] / $totalEntregas) * 100) : 0;
?>

<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Dashboard</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <section class="content">
        <div class="container-fluid">
            <!-- Small boxes (Stat box) -->
            <div class="row">
                <div class="col-lg-3 col-6">
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3><?php echo $totalClientes; ?></h3>
                            <p>Total Clientes</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <a href="clientes/listar.php" class="small-box-footer">
                            Ver mais <i class="fas fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>

                <div class="col-lg-3 col-6">
                    <div class="small-box bg-success">
                        <div class="inner">
                            <h3><?php echo $totalEntregas; ?></h3>
                            <p>Total Entregas</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-box"></i>
                        </div>
                        <a href="entregas/listar.php" class="small-box-footer">
                            Ver mais <i class="fas fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>

                <div class="col-lg-3 col-6">
                    <div class="small-box bg-warning">
                        <div class="inner">
                            <h3><?php echo $statusCounts['PENDENTE']; ?></h3>
                            <p>Pendentes</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-clock"></i>
                        </div>
                        <a href="entregas/listar.php?status=PENDENTE" class="small-box-footer">
                            Ver mais <i class="fas fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>

                <div class="col-lg-3 col-6">
                    <div class="small-box bg-danger">
                        <div class="inner">
                            <h3><?php echo $taxaEntrega; ?>%</h3>
                            <p>Taxa de Entrega</p>
                        </div>
                        <div class="icon">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <a href="relatorios.php" class="small-box-footer">
                            Ver mais <i class="fas fa-arrow-circle-right"></i>
                        </a>
                    </div>
                </div>
            </div>

            <!-- Status das Entregas -->
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">Status das Entregas</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="info-box">
                                        <span class="info-box-icon bg-warning"><i class="fas fa-clock"></i></span>
                                        <div class="info-box-content">
                                            <span class="info-box-text">Pendentes</span>
                                            <span class="info-box-number"><?php echo $statusCounts['PENDENTE']; ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="info-box">
                                        <span class="info-box-icon bg-info"><i class="fas fa-truck"></i></span>
                                        <div class="info-box-content">
                                            <span class="info-box-text">Em Trânsito</span>
                                            <span class="info-box-number"><?php echo $statusCounts['EM_TRANSITO']; ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="info-box">
                                        <span class="info-box-icon bg-success"><i class="fas fa-check"></i></span>
                                        <div class="info-box-content">
                                            <span class="info-box-text">Entregues</span>
                                            <span class="info-box-number"><?php echo $statusCounts['ENTREGUE']; ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="info-box">
                                        <span class="info-box-icon bg-danger"><i class="fas fa-times"></i></span>
                                        <div class="info-box-content">
                                            <span class="info-box-text">Cancelados</span>
                                            <span class="info-box-number"><?php echo $statusCounts['CANCELADO']; ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Entregas Recentes -->
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">Entregas Recentes</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>Código</th>
                                            <th>Descrição</th>
                                            <th>Cliente</th>
                                            <th>Status</th>
                                            <th>Data</th>
                                            <th>Ações</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (empty($entregasRecentes)): ?>
                                            <tr>
                                                <td colspan="6" class="text-center">Nenhuma entrega encontrada</td>
                                            </tr>
                                        <?php else: ?>
                                            <?php foreach ($entregasRecentes as $entrega): ?>
                                                <tr>
                                                    <td><?php echo $entrega['codigo']; ?></td>
                                                    <td><?php echo $entrega['descricao']; ?></td>
                                                    <td><?php echo $entrega['cliente_nome']; ?></td>
                                                    <td>
                                                        <?php
                                                        $statusClass = '';
                                                        switch($entrega['status']) {
                                                            case 'PENDENTE':
                                                                $statusClass = 'bg-warning';
                                                                break;
                                                            case 'EM_TRANSITO':
                                                                $statusClass = 'bg-info';
                                                                break;
                                                            case 'ENTREGUE':
                                                                $statusClass = 'bg-success';
                                                                break;
                                                            case 'CANCELADO':
                                                                $statusClass = 'bg-danger';
                                                                break;
                                                        }
                                                        ?>
                                                        <span class="badge <?php echo $statusClass; ?>">
                                                            <?php echo $entrega['status']; ?>
                                                        </span>
                                                    </td>
                                                    <td><?php echo formatarData($entrega['created_at']); ?></td>
                                                    <td>
                                                        <a href="entregas/editar.php?id=<?php echo $entrega['id']; ?>" class="btn btn-sm btn-primary">
                                                            <i class="fas fa-edit"></i>
                                                        </a>
                                                        <a href="entregas/excluir.php?id=<?php echo $entrega['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Tem certeza?')">
                                                            <i class="fas fa-trash"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php require_once 'includes/footer.php'; ?>