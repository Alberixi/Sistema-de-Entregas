/*
 * Sistema de Entregas - JavaScript Personalizado
 * Funcionalidades interativas e melhorias de UX
 */

$(document).ready(function() {
    'use strict';

    // Inicialização de tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Inicialização de popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });

    // Auto-hide alerts after 5 seconds
    setTimeout(function() {
        $('.alert').fadeOut();
    }, 5000);

    // Form validation styling
    $('form input, form select, form textarea').on('blur', function() {
        if ($(this).val() === '') {
            $(this).addClass('is-invalid');
        } else {
            $(this).removeClass('is-invalid');
            $(this).addClass('is-valid');
        }
    });

    // Search functionality
    $('#searchInput').on('keyup', function() {
        var value = $(this).val().toLowerCase();
        $('#dataTable tbody tr').filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
        });
    });

    // Confirm delete actions
    $('.delete-btn').on('click', function(e) {
        e.preventDefault();
        var url = $(this).attr('href');
        
        Swal.fire({
            title: 'Tem certeza?',
            text: "Esta ação não pode ser desfeita!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#F39C12',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'Sim, excluir!',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = url;
            }
        });
    });

    // Status change animations
    $('.status-badge').on('click', function() {
        $(this).addClass('animate__animated animate__pulse');
        setTimeout(function() {
            $('.status-badge').removeClass('animate__animated animate__pulse');
        }, 1000);
    });

    // Loading spinner for forms
    $('form').on('submit', function() {
        var submitBtn = $(this).find('button[type="submit"]');
        var originalText = submitBtn.html();
        
        submitBtn.prop('disabled', true);
        submitBtn.html('<i class="fas fa-spinner fa-spin"></i> Processando...');
        
        // Re-enable after 5 seconds in case of network issues
        setTimeout(function() {
            submitBtn.prop('disabled', false);
            submitBtn.html(originalText);
        }, 5000);
    });

    // Dynamic form fields based on selection
    $('#clienteSelect').on('change', function() {
        var clienteId = $(this).val();
        if (clienteId) {
            // Load client data via AJAX
            $.ajax({
                url: 'api/get_cliente.php',
                method: 'POST',
                data: { id: clienteId },
                dataType: 'json',
                success: function(data) {
                    $('#endereco').val(data.endereco);
                    $('#cidade').val(data.cidade);
                    $('#estado').val(data.estado);
                    $('#cep').val(data.cep);
                },
                error: function() {
                    toastr.error('Erro ao carregar dados do cliente');
                }
            });
        }
    });

    // CEP mask and auto-fill
    $('#cep').on('blur', function() {
        var cep = $(this).val().replace(/\D/g, '');
        if (cep.length === 8) {
            $.ajax({
                url: 'https://viacep.com.br/ws/' + cep + '/json/',
                dataType: 'json',
                success: function(data) {
                    if (!data.erro) {
                        $('#endereco').val(data.logradouro);
                        $('#cidade').val(data.localidade);
                        $('#estado').val(data.uf);
                        toastr.success('CEP encontrado e dados preenchidos!');
                    } else {
                        toastr.error('CEP não encontrado');
                    }
                },
                error: function() {
                    toastr.error('Erro ao consultar CEP');
                }
            });
        }
    });

    // Phone mask
    $('#telefone').on('input', function() {
        var value = $(this).val().replace(/\D/g, '');
        var formattedValue = '';
        
        if (value.length <= 2) {
            formattedValue = '(' + value;
        } else if (value.length <= 6) {
            formattedValue = '(' + value.substring(0, 2) + ') ' + value.substring(2);
        } else if (value.length <= 10) {
            formattedValue = '(' + value.substring(0, 2) + ') ' + value.substring(2, 6) + '-' + value.substring(6);
        } else {
            formattedValue = '(' + value.substring(0, 2) + ') ' + value.substring(2, 7) + '-' + value.substring(7, 11);
        }
        
        $(this).val(formattedValue);
    });

    // CEP mask
    $('#cep').on('input', function() {
        var value = $(this).val().replace(/\D/g, '');
        var formattedValue = '';
        
        if (value.length <= 5) {
            formattedValue = value;
        } else {
            formattedValue = value.substring(0, 5) + '-' + value.substring(5, 8);
        }
        
        $(this).val(formattedValue);
    });

    // Date picker initialization
    $('.date-picker').datepicker({
        format: 'dd/mm/yyyy',
        autoclose: true,
        todayHighlight: true,
        language: 'pt-BR'
    });

    // Print functionality
    $('.print-btn').on('click', function() {
        window.print();
    });

    // Export functionality
    $('.export-btn').on('click', function() {
        var format = $(this).data('format');
        var periodo = $('#periodoSelect').val();
        window.location.href = 'relatorios.php?exportar=' + format + '&periodo=' + periodo;
    });

    // Chart initialization (if Chart.js is loaded)
    if (typeof Chart !== 'undefined') {
        // Status distribution chart
        var statusCtx = document.getElementById('statusChart');
        if (statusCtx) {
            new Chart(statusCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Pendente', 'Em Trânsito', 'Entregue', 'Cancelado'],
                    datasets: [{
                        data: [
                            $('#pendenteCount').val() || 0,
                            $('#transitoCount').val() || 0,
                            $('#entregueCount').val() || 0,
                            $('#canceladoCount').val() || 0
                        ],
                        backgroundColor: ['#F39C12', '#3498DB', '#27AE60', '#E74C3C'],
                        borderColor: '#F39C12',
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });
        }

        // Monthly delivery chart
        var monthlyCtx = document.getElementById('monthlyChart');
        if (monthlyCtx) {
            new Chart(monthlyCtx, {
                type: 'bar',
                data: {
                    labels: JSON.parse($('#monthlyLabels').val() || '[]'),
                    datasets: [{
                        label: 'Entregas',
                        data: JSON.parse($('#monthlyData').val() || '[]'),
                        backgroundColor: '#5DADE2',
                        borderColor: '#F39C12',
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }
    }

    // Real-time search with debounce
    var searchTimeout;
    $('#searchInput').on('keyup', function() {
        clearTimeout(searchTimeout);
        var value = $(this).val();
        
        searchTimeout = setTimeout(function() {
            if (value.length > 2 || value.length === 0) {
                // Perform search
                performSearch(value);
            }
        }, 300);
    });

    function performSearch(query) {
        $.ajax({
            url: 'api/search.php',
            method: 'POST',
            data: { query: query, type: $('#searchType').val() },
            dataType: 'json',
            success: function(data) {
                updateSearchResults(data);
            },
            error: function() {
                toastr.error('Erro na busca');
            }
        });
    }

    function updateSearchResults(results) {
        var container = $('#searchResults');
        container.empty();
        
        if (results.length === 0) {
            container.html('<div class="text-center text-muted">Nenhum resultado encontrado</div>');
            return;
        }
        
        results.forEach(function(item) {
            var html = '<div class="search-result-item">';
            html += '<h6>' + item.title + '</h6>';
            html += '<p class="text-muted mb-1">' + item.description + '</p>';
            html += '<a href="' + item.link + '" class="btn btn-sm btn-primary">Ver detalhes</a>';
            html += '</div>';
            container.append(html);
        });
    }

    // Sidebar toggle animation
    $('[data-widget="pushmenu"]').on('click', function() {
        $('.wrapper').toggleClass('sidebar-collapse');
    });

    // Fullscreen toggle
    $('[data-widget="fullscreen"]').on('click', function() {
        if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen();
        } else {
            if (document.exitFullscreen) {
                document.exitFullscreen();
            }
        }
    });

    // Keyboard shortcuts
    $(document).on('keydown', function(e) {
        // Ctrl/Cmd + K for search
        if ((e.ctrlKey || e.metaKey) && e.keyCode === 75) {
            e.preventDefault();
            $('#searchInput').focus();
        }
        
        // Ctrl/Cmd + N for new record
        if ((e.ctrlKey || e.metaKey) && e.keyCode === 78) {
            e.preventDefault();
            window.location.href = $('.add-new-btn').attr('href');
        }
        
        // Escape to close modals
        if (e.keyCode === 27) {
            $('.modal').modal('hide');
        }
    });

    // Initialize tooltips for dynamically added content
    $(document).on('DOMNodeInserted', function(e) {
        var newTooltips = $(e.target).find('[data-bs-toggle="tooltip"]');
        if (newTooltips.length > 0) {
            newTooltips.each(function() {
                new bootstrap.Tooltip(this);
            });
        }
    });

    // Form field validation on submit
    $('form').on('submit', function(e) {
        var isValid = true;
        var requiredFields = $(this).find('[required]');
        
        requiredFields.each(function() {
            if ($(this).val() === '') {
                $(this).addClass('is-invalid');
                isValid = false;
            } else {
                $(this).removeClass('is-invalid');
            }
        });
        
        if (!isValid) {
            e.preventDefault();
            toastr.error('Por favor, preencha todos os campos obrigatórios');
            $('html, body').animate({
                scrollTop: $('.is-invalid').first().offset().top - 100
            }, 500);
        }
    });

    // Auto-save draft functionality
    var autoSaveTimeout;
    $('form textarea, form input[type="text"]').on('input', function() {
        clearTimeout(autoSaveTimeout);
        autoSaveTimeout = setTimeout(function() {
            saveDraft();
        }, 2000);
    });

    function saveDraft() {
        var formData = $('form').serialize();
        $.ajax({
            url: 'api/save_draft.php',
            method: 'POST',
            data: formData,
            success: function() {
                toastr.info('Rascunho salvo automaticamente');
            },
            error: function() {
                // Silently fail for auto-save
            }
        });
    }

    // Load saved draft on page load
    function loadDraft() {
        $.ajax({
            url: 'api/load_draft.php',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                if (data) {
                    Object.keys(data).forEach(function(key) {
                        $('[name="' + key + '"]').val(data[key]);
                    });
                    toastr.info('Rascunho recuperado');
                }
            }
        });
    }

    // Call loadDraft on appropriate pages
    if (window.location.pathname.indexOf('adicionar.php') > -1 || 
        window.location.pathname.indexOf('editar.php') > -1) {
        loadDraft();
    }

    // Initialize DataTables if available
    if ($.fn.DataTable) {
        $('.data-table').DataTable({
            language: {
                url: '//cdn.datatables.net/plug-ins/1.10.24/i18n/Portuguese-Brasil.json'
            },
            pageLength: 10,
            responsive: true,
            dom: '<"row"<"col-sm-6"l><"col-sm-6"f>>' +
                 '<"row"<"col-sm-12"tr>>' +
                 '<"row"<"col-sm-5"i><"col-sm-7"p>>',
            initComplete: function() {
                this.api().columns().every(function() {
                    var column = this;
                    var select = $('<select><option value=""></option></select>')
                        .appendTo($(column.footer()).empty())
                        .on('change', function() {
                            var val = $.fn.dataTable.util.escapeRegex($(this).val());
                            column.search(val ? '^' + val + '$' : '', true, false).draw();
                        });
                    
                    column.data().unique().sort().each(function(d, j) {
                        select.append('<option value="' + d + '">' + d + '</option>');
                    });
                });
            }
        });
    }

    // Smooth scroll for anchor links
    $('a[href^="#"]').on('click', function(event) {
        var target = $(this.getAttribute('href'));
        if (target.length) {
            event.preventDefault();
            $('html, body').stop().animate({
                scrollTop: target.offset().top - 70
            }, 1000);
        }
    });

    // Add animation classes to elements when they come into view
    function animateOnScroll() {
        $('.animate-on-scroll').each(function() {
            var elementTop = $(this).offset().top;
            var elementBottom = elementTop + $(this).outerHeight();
            var viewportTop = $(window).scrollTop();
            var viewportBottom = viewportTop + $(window).height();
            
            if (elementBottom > viewportTop && elementTop < viewportBottom) {
                $(this).addClass('animate__animated animate__fadeInUp');
            }
        });
    }

    $(window).on('scroll', animateOnScroll);
    animateOnScroll(); // Initial check

    // Initialize select2 if available
    if ($.fn.select2) {
        $('.select2').select2({
            theme: 'bootstrap4',
            language: 'pt-BR'
        });
    }

    // File upload preview
    $('.file-upload').on('change', function() {
        var file = this.files[0];
        if (file) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('.file-preview').attr('src', e.target.result).show();
            };
            reader.readAsDataURL(file);
        }
    });

    // Copy to clipboard functionality
    $('.copy-btn').on('click', function() {
        var text = $(this).data('copy');
        navigator.clipboard.writeText(text).then(function() {
            toastr.success('Copiado para a área de transferência!');
        }).catch(function() {
            toastr.error('Erro ao copiar');
        });
    });

    // Initialize time picker if available
    if ($.fn.timepicker) {
        $('.time-picker').timepicker({
            showMeridian: false,
            defaultTime: 'current'
        });
    }

    // Add loading overlay to AJAX requests
    $(document).ajaxStart(function() {
        $('.loading-overlay').fadeIn();
    });

    $(document).ajaxStop(function() {
        $('.loading-overlay').fadeOut();
    });

    // Initialize color picker if available
    if ($.fn.colorpicker) {
        $('.color-picker').colorpicker();
    }

    // Initialize range slider if available
    if ($.fn.ionRangeSlider) {
        $('.range-slider').ionRangeSlider();
    }

    // Add confirmation for navigation away from unsaved forms
    var formChanged = false;
    $('form input, form select, form textarea').on('change', function() {
        formChanged = true;
    });

    $(window).on('beforeunload', function() {
        if (formChanged) {
            return 'Você tem alterações não salvas. Tem certeza que deseja sair?';
        }
    });

    $('form').on('submit', function() {
        formChanged = false;
    });

    console.log('Sistema de Entregas - JavaScript inicializado com sucesso!');
});

// Utility functions
function showNotification(message, type = 'info') {
    toastr.options = {
        "closeButton": true,
        "debug": false,
        "newestOnTop": false,
        "progressBar": true,
        "positionClass": "toast-top-right",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    };

    switch(type) {
        case 'success':
            toastr.success(message);
            break;
        case 'error':
            toastr.error(message);
            break;
        case 'warning':
            toastr.warning(message);
            break;
        default:
            toastr.info(message);
    }
}

function formatCurrency(value) {
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(value);
}

function formatDate(dateString) {
    var options = { year: 'numeric', month: '2-digit', day: '2-digit' };
    return new Date(dateString).toLocaleDateString('pt-BR', options);
}

function formatDateTime(dateString) {
    var options = { 
        year: 'numeric', 
        month: '2-digit', 
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit'
    };
    return new Date(dateString).toLocaleDateString('pt-BR', options);
}

function validateEmail(email) {
    var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function validatePhone(phone) {
    var re = /^\(\d{2}\)\s\d{4,5}-\d{4}$/;
    return re.test(phone);
}

function validateCEP(cep) {
    var re = /^\d{5}-\d{3}$/;
    return re.test(cep);
}

// Export functions for global use
window.showNotification = showNotification;
window.formatCurrency = formatCurrency;
window.formatDate = formatDate;
window.formatDateTime = formatDateTime;
window.validateEmail = validateEmail;
window.validatePhone = validatePhone;
window.validateCEP = validateCEP;