document.addEventListener('DOMContentLoaded', function () {
    const toggle = document.getElementById('theme-toggle');
    const icon = toggle.querySelector('i');

    // Carregar tema salvo
    const savedTheme = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);

    // Atualizar ícone
    icon.classList.remove('fa-moon', 'fa-sun');
    icon.classList.add(savedTheme === 'dark' ? 'fa-sun' : 'fa-moon');

    // Alternar tema ao clicar
    toggle.addEventListener('click', function () {
        const current = document.documentElement.getAttribute('data-theme');
        const newTheme = current === 'dark' ? 'light' : 'dark';

        // Aplicar novo tema
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);

        // Atualizar ícone
        icon.classList.remove('fa-moon', 'fa-sun');
        icon.classList.add(newTheme === 'dark' ? 'fa-sun' : 'fa-moon');
    });
});